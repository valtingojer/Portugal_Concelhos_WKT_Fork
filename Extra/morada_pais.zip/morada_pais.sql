
-- Dumping structure for table .morada_pais
CREATE TABLE IF NOT EXISTS `morada_pais` (
  `Id` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Nome` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table .morada_pais: ~0 rows (approximately)
REPLACE INTO `morada_pais` (`Id`, `Nome`) VALUES
	('pt', 'Portugal');
