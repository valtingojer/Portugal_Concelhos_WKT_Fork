
-- Dumping structure for table .morada_distrito
CREATE TABLE IF NOT EXISTS `morada_distrito` (
  `Id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Nome` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `PaisId` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Activo` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`Id`),
  KEY `IX_Morada_Distrito_PaisId` (`PaisId`),
  CONSTRAINT `FK_Morada_Distrito_Morada_Pais_PaisId` FOREIGN KEY (`PaisId`) REFERENCES `morada_pais` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table .morada_distrito: ~20 rows (approximately)
REPLACE INTO `morada_distrito` (`Id`, `Nome`, `PaisId`, `Activo`) VALUES
	('03454178-33DF-6FDF-0FEB-BE0F859397ED', 'Beja', 'pt', 0),
	('0B86F77E-29C2-4EB7-2F82-6583365939D6', 'Portalegre', 'pt', 0),
	('1A50BA80-1662-24F9-6093-027E28496803', 'Bragança', 'pt', 0),
	('1D0A59A1-7E05-3368-A4CC-1074328E5587', 'Leiria', 'pt', 0),
	('2BE28B05-7ACE-1323-6D7E-7A391F8D901D', 'Évora', 'pt', 0),
	('35C68DD3-51E8-54D0-452A-AF69DF112D6D', 'Lisboa', 'pt', 0),
	('463B0877-07FB-5853-65CC-7DEB6ECB5522', 'Aveiro', 'pt', 0),
	('469F5C50-11AC-0F12-7624-9F3EF07E0E02', 'Viana do Castelo', 'pt', 0),
	('5560F34D-1E60-3C04-03A0-12CDF93B3331', 'Guarda', 'pt', 0),
	('67DA9F31-D053-44B3-BFEB-993F9C965D54', 'Açores', 'pt', 0),
	('8ADE7C68-A1A6-8E92-193C-A2E859E96564', 'Faro', 'pt', 0),
	('91CC058D-9D08-0AF5-7508-B551C6EE63DB', 'Viseu', 'pt', 0),
	('9B6CD426-29DC-22BE-1B56-EDF98EFD3B56', 'Santarém', 'pt', 0),
	('AB9B3185-23ED-90B5-7651-0FA57F7A92EA', 'Castelo Branco', 'pt', 0),
	('C50D52B4-86A1-969C-9819-755DA7460A24', 'Coimbra', 'pt', 0),
	('C5C782DD-4CC9-32CA-3B31-22957CD36E69', 'Braga', 'pt', 0),
	('CA7A63D2-5BF8-5BA0-737E-0D813BF03CD4', 'Vila Real', 'pt', 0),
	('D4A6ADAF-7152-76AF-509B-CC0289BE9C1A', 'Setúbal', 'pt', 0),
	('DB314381-6D1F-125B-43FF-3A549D090304', 'Porto', 'pt', 0),
	('DE2A39F1-F5F0-4933-B775-8B89D35852E5', 'Madeira', 'pt', 0);
